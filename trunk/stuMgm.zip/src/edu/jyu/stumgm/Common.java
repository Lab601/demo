package edu.jyu.stumgm;

public class Common {

	public static final Object ADMIN_ROLE = "1";

}
