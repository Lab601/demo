package edu.jyu.stumgm.interceptor;

public class SecurityInterceptor {

}  
